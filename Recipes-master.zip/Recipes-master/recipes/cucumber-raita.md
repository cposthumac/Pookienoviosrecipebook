# Cucumber Raita  

## ingredients
* 1 cup yogurt  
* 1/8 tsp salt  
* 1/2 tsp ground cumin  
* 1 tbsp cilantro, finely chopped  
* 1 cup cucumber, chopped  
* 1–2 green chilies, chopped  
* 1 tsp lemon juice  
* water as needed  

## steps
1. Toast cumin in a dry pan until fragrant, then grind into a powder  
2. In a bowl, mix yogurt, salt, and cumin and mix thoroughly  
3. Add cilantro, cucumber, green chilies, and lemon juice  
4. Mix and add water as necessary to achieve proper consistency  
5. Optional: garnish with ground black pepper and more cumin  

## notes:  
* Add 1 tsp mint, 1 medium chopped onion (with 1/2 tsp sugar), 1" minced ginger, or 2 cloves minced garlic  

## based on:
* https://www.indianhealthyrecipes.com/raita-recipes-biryani-pulao-kababs  