# Bhindi Fry  

## ingredients  
* 1/2 lbs okra, cut into 1/2" pieces  
* 1 onion, finely chopped  
* 5 garlic cloves, lightly crushed (or 1/2 tsp asafoetida)  
* 1/2 tsp mustard seeds  
* 1/2 tsp cumin seeds  
* 2 dry red chilies, roughly torn  
* 1/4 tsp turmeric powder  
* 1 sprig curry leaves  
* 1 tbsp yogurt or lemon juice  
* salt to taste  

## steps
1. Heat oil in a pan over medium heat, add mustard seeds and hook until they pop and sputter  
2. Add cumin seeds and cook until fragrant  
3. Add curry leaves, chilies, and garlic, stir for a few seconds  
4. Add onions and sautee until transparent  
5. Add okra and turmeric, stir and sautee on medium-high heat for 3-4 minutes  
6. Reduce heat, add yogurt or lemon juice, let cook for 4-5 mintues, stirring  
7. Continue cooking until okra turns soft, about 15-20 minutes  
8. When ready, season with salt and serve  

## based on  
* https://www.sailusfood.com/okra-fry-recipe-andhra-style  

