# Roti  

## info  
* 20 minutes    
* 6–8 rotis    

## ingredients  
* 2 cups bread or all-purpose flour  
* 1 tsp salt  
* 2 tbps butter, melted  
* 2/3 cup water  

## steps
1. In food processor, pulse to mix together flour and salt  
2. Add melted butter and mix until crumbly  
3. Add water and run food processor until dough comes together  
4. Turn out onto a floured surface and knead until a tight ball forms  
5. Cover and let rest for 45 minutes  
6. Divide dough into 6–8 parts, roll each into a ball  
7. Heat cast iron pan over high heat  
8. Roll out roti as thin as possible, then add to pan and cook, flipping after about 30 seconds until translucent and cooked through  

## notes  
* Original recipe calls for the bread to be fried in 1/2 tsp butter each, but comes out great without it  

## based on  
* https://thefoodcharlatan.com/roti-buttery-indian-flatbread

