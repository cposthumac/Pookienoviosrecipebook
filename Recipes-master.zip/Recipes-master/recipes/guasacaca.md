# Guasacaca  
(Creamy Venezuelan guacamole-like sauce)

## info  
* 10 minutes    
* A crap-ton (easily halved)  

## ingredients  
* 2 avocadoes, roughly cut up  
* 1 small onion, quartered  
* 1 small green bell pepper, seeded and roughly chopped  
* 1 jalepeño, roughly chopped (optionally: remove seeds)  
* 2 medium cloves garlic  
* 1/2 cup cilantro leaves, roughly chopped  
* 1/4 cup parsley leaves, roughly chopped  
* 1/4 cup white vinegar  
* 1 tbsp lime juice  
* 1/3 cup olive oil  

## steps
1. Optional: in a cast iron pan over high heat, dry-roast the onions, bell pepper, and jalepeño until blackened  
2. Place everything except the olive oil in a food processor and pulse until finely chopped  
3. With motor running, drizzle the olive oil into the mixture  
4. Season with salt and pepper to taste  

## notes  
* Should keep at least several days in the fridge  
* Great on breakfast hash or fried yucca!  

## based on  
* https://www.seriouseats.com/recipes/2013/02/guasacaca-recipe.html  

