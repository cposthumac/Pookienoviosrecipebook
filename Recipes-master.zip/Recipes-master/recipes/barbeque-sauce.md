# (Ketchup-based) BBQ Sauce

## ingredients  
* 2/3 cup ketchup  
* 1/2 cup apple cider vinegar  
* generous 1/4 cup rub (see note)  

## steps
1. Add all ingredients to a small saucepan, stir well  
2. Bring to a simmer over medium heat for five minutes, stirring frequently  

## notes  
* Original recipe calls for 1/4 cup brown sugar, 2 tsp smoked paprika, 1 tsp ground cumin, 1 tsp kosher salt, and 1 tsp black pepper  

## based on  
* https://cooking.nytimes.com/recipes/1013116-simple-barbecue-sauce  

