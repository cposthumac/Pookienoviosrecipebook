# Roasted Parsnips and Carrots

## info  
* 1 hour  
* 4 servings  

## ingredients
* 2 lbs parsnips, peeled  
* 1 lb carrots, peeled  
* 3 tbsp olive oil  
* 1 tbsp kosher salt  
* Ground black pepper  
* 2 tbsp minced fresh dill or parsley (optional)  

## steps  
1. Preheat oven to 425ºF  
2. Slice vegetables into thick sticks, then cut into 1-inch pieces  
3. Place on sheet pan, add oil, salt, and pepper, then mix well  
4. Roast for 20–40 minutes, stirring occasionally, until tender  
5. Sprinkle with herbs and serve immediately  

## based on  
* https://www.foodnetwork.com/recipes/ina-garten/roasted-parsnips-and-carrots-recipe-1949073

