# Garlicky Cabbage and Fish Sauce  

## info  
* 10 minutes  
* side dish for two people  

## ingredients  
* 8–10 cloves garlic, smashed  
* 200 grams (about 1/8 head) green cabbage, cut into 2-inch pieces and pulled apart  
* 1 tbsp fish sauce  
* 1/4 tsp ground white or black pepper  
* 1–2 sliced Thai chilies (optional)  

## steps
1. Heat pan over medium heat and add enough oil to coat the bottom  
2. Add garlic immediately and cook, stirring, until edges start to turn golden  
3. Add cabbage, turn up heat to high, and toss to coat in the garlic oil  
4. Add fish sauce and pepper, toss and cook for 1–2 minutes  
5. Remove from heat and garnish with extra pepper  

## based on  
* https://hot-thai-kitchen.com/cabbage-fish-sauce  

