# Lemon Tahini Dressing

## info  
* About 5 minutes  
* 1.3 cups    

## ingredients
* 1/2 cup tahini  
* 2/3–3/4 cup water (as needed)  
* 3 tbsp lemon juice  
* 1 clove garlic, minced  
* 1 tbsp olive oil  
* 3/4 tsp sea salt  
* Black pepper  

## steps  
1. Whisk ingredients together, starting with 2/3-cup water and adding more as necessary  
2. Will keep for 5 days in fridge  

## based on  
* https://food52.com/recipes/28159-lemon-tahini-dressing

